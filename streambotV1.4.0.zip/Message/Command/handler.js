"use strict";
require("dotenv").config();
  
const _import  = require('../Connect/index.1.js');
const { Ctx } = _import;
const { MessageType, mentionedJid, MessageOptions, groupSettingChange } = Ft.baileys;
const { scommand, addCmd, getCommandPosition, checkSCommand, getCmd } = _import.Ctx._SCMD;
const { userbot } = _import.Ctx._UserDB;

const footerText = userbot.setting.packname;
const serialize = _import.Ctx.serializeM; 
const timestamp = Ft.speed();
const latensi = Ft.speed() - timestamp;
const exif = new Ft.Exif();
const changelog = global.config.changelog

module.exports = {
  async chatUpdate(conn, chat) {
  if (!chat.hasNewMessage) return;
 const msg = chat.messages.all()[0];
  try {
  if (!msg.message) return;
  if (msg.key && msg.key.remoteJid == 'status@broadcast') return;
 msg.message = (Object.keys(msg.message)[0] === 'ephemeralMessage') ? msg.message.ephemeralMessage.message: msg.message;
  if ((Object.keys(msg.message)[0] === 'ephemeralMessage' && JSON.stringify(msg.message).includes('EPHEMERAL_SETTING')) && msg.message.ephemeralMessage.message.protocolMessage.type === 3) {
    const bugc = true;
 if (bugc === false) return;
 if (msg.key.fromMe) return;
conn.groupRemove(msg.key.remoteJid, [msg.participant]).catch((e) => console.log(e));
conn.sendMessage(msg.key.remoteJid, "\n".repeat(420) + `@⁨${msg.participant.split('@')[0]}` + '*Maaf Anda Di Keluarkan*\n\n*Karena Telah Mengirim Virtex*', MessageType.text, {contextInfo:{mentionedJid:[msg.participant + "@s.whatsapp.net"]}});
   };
    const isPublic = true;
 if (!isPublic) {
 if (!msg.key.fromMe) return;
   };
    const m = serialize.smsg(conn, msg);
 if (m.isBaileys === true) return;
 if (msg.isBaileys) return;
    const type = Object.keys(msg.message)[0]; 
    const content = JSON.stringify(msg.message)
    const l = 1;
    const prefixRegEx = /^[!&z?=#.+\/]/gi  
    const cmd = 
  (type === 'conversation' && msg.message.conversation) 
  ? msg.message.conversation 
  : (type == 'imageMessage') && msg.message.imageMessage.caption 
  ? msg.message.imageMessage.caption 
  : (type == 'videoMessage') && msg.message.videoMessage.caption 
  ? msg.message.videoMessage.caption 
  : (type == 'extendedTextMessage') && msg.message.extendedTextMessage.text 
  ? msg.message.extendedTextMessage.text 
  : (type == 'buttonsResponseMessage') && msg.message[type].selectedButtonId 
  ? msg.message[type].selectedButtonId 
  : (type == 'stickerMessage') && (getCmd(msg.message.stickerMessage.fileSha256.toString('hex')) !== null && getCmd(msg.message.stickerMessage.fileSha256.toString('base64')) !== undefined) 
  ? getCmd(msg.message.stickerMessage.fileSha256.toString('base64')) 
  : "".slice(1).trim().split(/ +/).shift().toLowerCase();
    const multi = true;
 if (multi){
    var prefix = /^[°•π÷×¶∆£¢€¥®™=|~!#$%^&.?/\\©^z+*@,;]/.test(cmd) ? cmd.match(/^[°•π÷×¶∆£¢€¥®™=|~!#$%^&.?/\\©^z+*,;]/gi) : '#';
  } else {
    var prefix = userbot.setting.prefix;
  };
    const body = 
  (type === "conversation" && msg.message.conversation.startsWith(prefix))
  ? msg.message.conversation 
  : (type == "imageMessage") && msg.message[type].caption.startsWith(prefix) 
  ? msg.message[type].caption 
  : (type == 'videoMessage') && msg.message[type].caption.startsWith(prefix) 
  ? msg.message[type].caption 
  : (type == 'extendedTextMessage') && msg.message[type].text.startsWith(prefix) 
  ? msg.message[type].text 
  : (type == 'listResponseMessage') && msg.message[type].singleSelectReply.selectedRowId 
  ? msg.message[type].singleSelectReply.selectedRowId 
  : (type == 'buttonsResponseMessage') && msg.message[type].selectedButtonId 
  ? msg.message[type].selectedButtonId 
  : (type == 'stickerMessage') && (getCmd(msg.message[type].fileSha256.toString('base64')) !== null && getCmd(msg.message[type].fileSha256.toString('base64')) !== undefined) 
  ? getCmd(msg.message[type].fileSha256.toString('base64')) 
  : "";
    const budy =
  (type === "conversation")
  ? msg.message.conversation
  : (type === "extendedTextMessage")
  ? msg.message.extendedTextMessage.text
  : "";
    const listButton = 
   (type == 'listResponseMessage') 
   ? msg.message.listResponseMessage.singleSelectReply.selectedRowId 
   : '';
    const selectbutton = 
   (type == 'buttonsResponseMessage') 
   ? msg.message.buttonsResponseMessage.selectedButtonId 
   : '';
try {
    var pporang = await conn.getProfilePicture(`${m.sender.split('@')[0]}@s.whatsapp.net`)
   } catch {
    var pporang = userbot.image.undefined
    }
    const fakeimage = await Ft.getBuffer(pporang);
    const args = body.trim().split(/ +/).slice(1);
    const command = body.toLowerCase().split(' ')[0] || '';
    const isCmd = command.startsWith(prefix);
    const totalchat = await conn.chats.all();
    const ownerNumber = userbot.owner
    const botNumber = conn.user.jid;
    const createName = msg.key.fromMe ? conn.user.jid : conn.contacts[m.sender] || { notify: jid.replace(/@.+/, '') }
    const pushName = msg.key.fromMe ? conn.user.name : createName.notify || createName.vname || createName.name || '-';
    const isOwner = ownerNumber.includes(m.sender)
    const groupMetadata = m.isGroup ? await conn.groupMetadata(m.chat) : '';
    const groupName = m.isGroup ? groupMetadata.subject : "";
    const groupId = m.isGroup ? groupMetadata.jid : "";
    const groupMembers = m.isGroup ? groupMetadata.participants : "";
    const getGroupAdmins = (participants) => {
global.admins = []
for (let i of participants) {
i.isAdmin ? admins.push(i.jid) : ''
}
return admins
}
const groupAdmins = m.isGroup ? getGroupAdmins(groupMembers) : ""; 
const groupDesc = m.isGroup ? groupMetadata.desc : "";
const groupOwner = m.isGroup ? groupMetadata.owner : "";
const isBotGroupAdmins = groupAdmins.includes(botNumber) || false;
  var floc = {
  key : {
    participant : '0@s.whatsapp.net', 
    remoteJid: 'status@broadcast',
  },
message: {
liveLocationMessage: {
caption: `${latensi.toFixed(4)} ms | ${pushName}`,
thumbnail: fakeimage,
  },
  },
  };
  var ftrol = {
  key: {
    participant : '0@s.whatsapp.net', 
    remoteJid: 'status@broadcast',
  },
message: { 
orderMessage: { 
itemCount: 99,
status: 200,
thumbnail: fakeimage,
surface: 200,
message: `${latensi.toFixed(4)} ms | ${pushName}`,
orderTitle: footerText,
sellerJid: "0@s.whatsapp.net",
  },
  },
  };
  if (listButton == 'MenuLOCATION') {
  var { send3ButtonLoc } = _import.Ctx.serializeM;
  var { menu } = _import.Ctx._write;
  var teks = menu(prefix, l);
  conn.send3ButtonLoc(m.chat, await ( await Ft.fetch(userbot.image.butmag2)).buffer(), teks, footerText, 'Credits', 'Credits', 'Rules', 'Rules', 'Changelog', 'Changelog', m)
} else if (listButton == 'MenuCATALOG') {
  var { menu } = _import.Ctx._write;
  var teks = menu(prefix, l);
  var res = conn.prepareMessageFromContent(m.chat,{ "orderMessage": { "itemCount": 321, "message": teks, "thumbnail": fakeimage, "surface": 'CATALOG' }}, {quoted:ftrol, })
  conn.relayWAMessage(res)
} else if (listButton == 'MenuCATALOGv2') {
  var { menu } = _import.Ctx._write;
  var teks = menu(prefix, l);
  var author = userbot.setting.author;
  var imgs = await conn.prepareMessage('0@c.us', fakeimage, MessageType.image, { thumbnail: fakeimage })
  var imgCatalog = imgs.message.imageMessage
  var ctlg = await conn.prepareMessageFromContent(m.chat, { "productMessage": { "product": { "productImage": imgCatalog, "productId": "4715716298440452", "title": `𝗠𝗘𝗡𝗨 𝗖𝗔𝗧𝗔𝗟𝗢𝗚 𝗣𝗥𝗢𝗗𝗨𝗖𝗧`, "description": teks, "footerText": author, "currencyCode": "IDR", "priceAmount1000": "100000000","productImageCount": 1, "firstImageId": 1, "salePriceAmount1000": "35000000","retailerId": footerText, "url": "https://github.com/Arifirazzaq2001" }, "businessOwnerJid": "6281261324817@s.whatsapp.net" }},{ quoted: ftrol, mimetype: 'image/jpeg' })
  conn.relayWAMessage(ctlg)
} else if (listButton == 'MenuPPTX') {
  var { menu } = _import.Ctx._write;
  var author = userbot.setting.author;
  var teks = menu(prefix, l);
  conn.sendMessage(m.chat, { contentText: teks, buttons: [{buttonId: 'Credits', buttonText: {displayText: 'Credits️'}, type: 1},{buttonId: 'Rules', buttonText: {displayText: 'Rules'}, type: 1},{buttonId: 'Changelog' , buttonText: {displayText: 'Changelog'}, type: 1}], "headerType": "DOCUMENT", "documentMessage": { "url": userbot.image.mmgmag, "mimetype": "application/vnd.openxmlformats-officedocument.presentationml.presentation", "title": footerText, "fileSha256": "8Xfe3NQDhjwVjR54tkkShLDGrIFKR9QT5EsthPyxDCI=", "fileLength": 999999999999, "pageCount": 999, "mediaKey": "XWv4hcnpGY51qEVSO9+e+q6LYqPR3DbtT4iqS9yKhkI=", "fileName": author, "fileEncSha256": "NI9ykWUcXKquea4BmH7GgzhMb3pAeqqwE+MTFbH/Wk8=", "directPath": "/v/t62.7119-24/35160407_568282564396101_3119299043264875885_n.enc?ccb=11-4&oh=d43befa9a76b69d757877c3d430a0752&oe=61915CEC", "mediaKeyTimestamp": "1634472176", "jpegThumbnail": Ft.fs.readFileSync('./src/image/action/action.1.jpeg')}}, MessageType.buttonsMessage, { quoted: floc, thumbnail: Ft.fs.readFileSync('./src/image/action/action.2.jpeg'), contextInfo: { forwardingScore: 508, isForwarded: true, externalAdReply: { title: `${Ft.time}`, body: `${Ft.tanggal}\n⎇ ${Ft.waktu} ${Ft.week} ${Ft.weton}`, thumbnail: Ft.fs.readFileSync('./src/image/action/action.3.jpeg'), mediaType:"2", previewType: "VIDEO", mediaUrl: "https://youtu.be/nLEYHaaB6x0"}}})
} else if (listButton == 'MenuXLSX') {
  var { menu } = _import.Ctx._write;
  var author = userbot.setting.author;
  var teks = menu(prefix, l);
  conn.sendMessage(m.chat, { contentText: teks, buttons: [{buttonId: 'Credits', buttonText: {displayText: 'Credits️'}, type: 1},{buttonId: 'Rules', buttonText: {displayText: 'Rules'}, type: 1},{buttonId: 'Changelog' , buttonText: {displayText: 'Changelog'}, type: 1}], "headerType": "DOCUMENT", "documentMessage": { "url": userbot.image.mmgmag, "mimetype": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "title": footerText, "fileSha256": "8Xfe3NQDhjwVjR54tkkShLDGrIFKR9QT5EsthPyxDCI=", "fileLength": 999999999999, "pageCount": 999, "mediaKey": "XWv4hcnpGY51qEVSO9+e+q6LYqPR3DbtT4iqS9yKhkI=", "fileName": author, "fileEncSha256": "NI9ykWUcXKquea4BmH7GgzhMb3pAeqqwE+MTFbH/Wk8=", "directPath": "/v/t62.7119-24/35160407_568282564396101_3119299043264875885_n.enc?ccb=11-4&oh=d43befa9a76b69d757877c3d430a0752&oe=61915CEC", "mediaKeyTimestamp": "1634472176", "jpegThumbnail": Ft.fs.readFileSync('./src/image/action/action.4.jpeg')}}, MessageType.buttonsMessage, { quoted: floc, thumbnail: Ft.fs.readFileSync('./src/image/action/action.5.jpeg'), contextInfo: { forwardingScore: 508, isForwarded: true, externalAdReply: { title: `${Ft.time}`, body: `${Ft.tanggal}\n⎇ ${Ft.waktu} ${Ft.week} ${Ft.weton}`, thumbnail: Ft.fs.readFileSync('./src/image/action/action.6.jpeg'), mediaType:"2", previewType: "VIDEO", mediaUrl: "https://youtu.be/nLEYHaaB6x0"}}})
} else if (listButton == 'MenuDOCX') {
  var { menu } = _import.Ctx._write;
  var author = userbot.setting.author;
  var teks = menu(prefix, l);
  conn.sendMessage(m.chat, { contentText: teks, buttons: [{buttonId: 'Credits', buttonText: {displayText: 'Credits️'}, type: 1},{buttonId: 'Rules', buttonText: {displayText: 'Rules'}, type: 1},{buttonId: 'Changelog' , buttonText: {displayText: 'Changelog'}, type: 1}], "headerType": "DOCUMENT", "documentMessage": { "url": userbot.image.mmgmag, "mimetype": "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "title": footerText, "fileSha256": "8Xfe3NQDhjwVjR54tkkShLDGrIFKR9QT5EsthPyxDCI=", "fileLength": 999999999999, "pageCount": 999, "mediaKey": "XWv4hcnpGY51qEVSO9+e+q6LYqPR3DbtT4iqS9yKhkI=", "fileName": author, "fileEncSha256": "NI9ykWUcXKquea4BmH7GgzhMb3pAeqqwE+MTFbH/Wk8=", "directPath": "/v/t62.7119-24/35160407_568282564396101_3119299043264875885_n.enc?ccb=11-4&oh=d43befa9a76b69d757877c3d430a0752&oe=61915CEC", "mediaKeyTimestamp": "1634472176", "jpegThumbnail": Ft.fs.readFileSync('./src/image/action/action.7.jpeg')}}, MessageType.buttonsMessage, { quoted: floc, thumbnail: Ft.fs.readFileSync('./src/image/action/action.8.jpeg'), contextInfo: { forwardingScore: 508, isForwarded: true, externalAdReply: { title: `${Ft.time}`, body: `${Ft.tanggal}\n⎇ ${Ft.waktu} ${Ft.week} ${Ft.weton}`, thumbnail: Ft.fs.readFileSync('./src/image/action/action.9.jpeg'), mediaType:"2", previewType: "VIDEO", mediaUrl: "https://youtu.be/nLEYHaaB6x0"}}})
} else if (listButton == 'MenuZIP') {
  var { menu } = _import.Ctx._write;
  var author = userbot.setting.author;
  var teks = menu(prefix, l);
  conn.sendMessage(m.chat, { contentText: teks, buttons: [{buttonId: 'Credits', buttonText: {displayText: 'Credits️'}, type: 1},{buttonId: 'Rules', buttonText: {displayText: 'Rules'}, type: 1},{buttonId: 'Changelog' , buttonText: {displayText: 'Changelog'}, type: 1}], "headerType": "DOCUMENT", "documentMessage": { "url": userbot.image.mmgmag, "mimetype": "application/zip", "title": footerText, "fileSha256": "8Xfe3NQDhjwVjR54tkkShLDGrIFKR9QT5EsthPyxDCI=", "fileLength": 999999999999, "pageCount": 999, "mediaKey": "XWv4hcnpGY51qEVSO9+e+q6LYqPR3DbtT4iqS9yKhkI=", "fileName": author, "fileEncSha256": "NI9ykWUcXKquea4BmH7GgzhMb3pAeqqwE+MTFbH/Wk8=", "directPath": "/v/t62.7119-24/35160407_568282564396101_3119299043264875885_n.enc?ccb=11-4&oh=d43befa9a76b69d757877c3d430a0752&oe=61915CEC", "mediaKeyTimestamp": "1634472176", "jpegThumbnail": Ft.fs.readFileSync('./src/image/action/action.10.jpeg')}}, MessageType.buttonsMessage, { quoted: floc, thumbnail: Ft.fs.readFileSync('./src/image/action/action.11.jpeg'), contextInfo: { forwardingScore: 508, isForwarded: true, externalAdReply: { title: `${Ft.time}`, body: `${Ft.tanggal}\n⎇ ${Ft.waktu} ${Ft.week} ${Ft.weton}`, thumbnail: Ft.fs.readFileSync('./src/image/action/action.12.jpeg'), mediaType:"2", previewType: "VIDEO", mediaUrl: "https://youtu.be/nLEYHaaB6x0"}}})
} else if (listButton == 'MenuPDF') {
  var { menu } = _import.Ctx._write;
  var author = userbot.setting.author;
  var teks = menu(prefix, l);
  conn.sendMessage(m.chat, { contentText: teks, buttons: [{buttonId: 'Credits', buttonText: {displayText: 'Credits️'}, type: 1},{buttonId: 'Rules', buttonText: {displayText: 'Rules'}, type: 1},{buttonId: 'Changelog' , buttonText: {displayText: 'Changelog'}, type: 1}], "headerType": "DOCUMENT", "documentMessage": { "url": userbot.image.mmgmag, "mimetype": "application/pdf", "title": footerText, "fileSha256": "8Xfe3NQDhjwVjR54tkkShLDGrIFKR9QT5EsthPyxDCI=", "fileLength": 999999999999, "pageCount": 999, "mediaKey": "XWv4hcnpGY51qEVSO9+e+q6LYqPR3DbtT4iqS9yKhkI=", "fileName": author, "fileEncSha256": "NI9ykWUcXKquea4BmH7GgzhMb3pAeqqwE+MTFbH/Wk8=", "directPath": "/v/t62.7119-24/35160407_568282564396101_3119299043264875885_n.enc?ccb=11-4&oh=d43befa9a76b69d757877c3d430a0752&oe=61915CEC", "mediaKeyTimestamp": "1634472176", "jpegThumbnail": Ft.fs.readFileSync('./src/image/action/action.13.jpeg')}}, MessageType.buttonsMessage, { quoted: floc, thumbnail: Ft.fs.readFileSync('./src/image/action/action.14.jpeg'), contextInfo: { forwardingScore: 508, isForwarded: true, externalAdReply: { title: `${Ft.time}`, body: `${Ft.tanggal}\n⎇ ${Ft.waktu} ${Ft.week} ${Ft.weton}`, thumbnail: Ft.fs.readFileSync('./src/image/action/action.15.jpeg'), mediaType:"2", previewType: "VIDEO", mediaUrl: "https://youtu.be/nLEYHaaB6x0"}}})
} else if (selectbutton == 'Rules') {
  var { sendButtonLoc } = _import.Ctx.serializeM;
  var { rules } = _import.Ctx._write;
  var teks = rules(prefix, l)
  conn.sendButtonLoc(m.chat, await ( await Ft.fetch(userbot.image.butmag3)).buffer(), teks, footerText, 'Menu', 'Menu', m) 
} else if (selectbutton == 'Menu') {
  var { menu } = _import.Ctx._write;
  var listMsg = {
  title: "「 *𝗦𝗧𝗥𝗘𝗔𝗠 𝗕𝗢𝗧* 」", 
  buttonText: 'Daftar Menu',
  footerText: footerText,
  description: `\nHai kak @${m.sender.split('@')[0]}, Silahkan pilih menu disini`,
  sections: [
  {
"title": `Originally Type 1`, 
"rows" : [
  {
 "title": "𝗠𝗘𝗡𝗨 𝗟𝗢𝗖𝗔𝗧𝗜𝗢𝗡 𝗕𝗨𝗧𝗧𝗢𝗡",
 "rowId": "MenuLOCATION"
  }]
  },{
 "title": `Catalog Type 1`, 
 "rows" : [
  {
 "title": "𝗠𝗘𝗡𝗨 𝗖𝗔𝗧𝗔𝗟𝗢𝗚",
 "description": "\nKatalog adalah daftar koleksi sebuah pusat dokumentasi atau beberapa pusat dokumentasi yang disusun menurut sistem tertentu.", 
 "rowId": "MenuCATALOG"
  }]
  },{
 "title": `Catalog Type 2`, 
 "rows" : [
  {
 "title": "𝗠𝗘𝗡𝗨 𝗖𝗔𝗧𝗔𝗟𝗢𝗚 𝗣𝗥𝗢𝗗𝗨𝗖𝗧",
 "description": "\nKatalog Produk adalah kumpulan produk dan informasi harga mereka. ... Buat daftar diskon untuk menawarkan produk dan layanan dengan harga yang berbeda, tergantung pada jumlah yang dibeli. Mengkonfigurasikan daftar diskon. Mendefinisikan pengukuran atau kuantitas produk Anda akan tersedia.", 
 "rowId": "MenuCATALOGv2"
  }]
  },{
 "title": `Dokument Type 1`, 
 "rows" : [
  {
 "title": "𝗠𝗘𝗡𝗨 𝗣𝗣𝗧𝗫",
 "description": "\nMicrosoft PowerPoint atau Microsoft Office PowerPoint atau PowerPoint adalah sebuah program komputer untuk presentasi yang dikembangkan oleh Microsoft di dalam paket aplikasi kantoran mereka, Microsoft Office, selain Microsoft Word, Excel, Access dan beberapa program lainnya.", 
 "rowId": "MenuPPTX"
  }]
  },{
 "title": `Dokument Type 2`,
 "rows": [ 
  {
 "title": "𝗠𝗘𝗡𝗨 𝗫𝗟𝗦𝗫",
 "description": "\nData atau file dengan ekstensi .XLSX adalah sebuah file Microsoft Excel Open XML Spreadsheet yang dibuat memakai aplikasi Microsoft Excel. Namun, karena formatnya open XML, file ini bisa dibuka oleh sejumlah aplikasi, seperti Open Office, Google Docs, hingga Apple Numbers.", 
 "rowId": "MenuXLSX"
  }]
  },{
 "title": `Dokument Type 3`,
 "rows": [ 
  {
 "title": "𝗠𝗘𝗡𝗨 𝗗𝗢𝗖𝗫",
 "description": "\nDilansir dari Hubspot, Google Docs adalah layanan pengolah kata yang diberikan kepada pengguna Google secara gratis. Singkatnya, jika kamu sudah familiar dengan Microsoft Word, maka Google Docs adalah versi lain yang memungkinkan kamu untuk membuat, mengedit, dan membagikan dokumen tertulis secara online.", 
 "rowId": "MenuDOCX"
  }]
  },{
 "title": `Dokument Type 4`,
 "rows": [ 
  {
 "title": "𝗠𝗘𝗡𝗨 𝗭𝗜𝗣",
 "description": "\nZIP merupakan format file arsip yang digunakan secara luas untuk mengompresi atau memampatkan satu atau beberapa file bersama-sama menjadi ke dalam satu lokasi sehingga mengurangi ukurannya secara keseluruhan serta memudahkan pemindahan file tersebut. File ZIP bekerja serupa dengan folder standar pada komputer Anda.", 
 "rowId": "MenuZIP"
  }]
  },{
 "title": `Dokument Type 5`,
 "rows": [ 
  {
 "title": "𝗠𝗘𝗡𝗨 𝗣𝗗𝗙",
 "description": "\nPortable Document Format adalah sebuah format berkas yang dibuat oleh Adobe Systems pada tahun 1993 untuk keperluan pertukaran dokumen digital. Format PDF digunakan untuk merepresentasikan dokumen dua dimensi yang meliputi teks, huruf, citra dan grafik vektor dua dimensi.", 
 "rowId": "MenuPDF"
  }]
  }
  ],
  listType: 1
  }
  conn.sendMessage(m.chat, listMsg, MessageType.listMessage, {contextInfo: { mentionedJid: [m.sender]}, quoted:msg })
} else if (selectbutton == 'Credits') {
  var { sendButtonLoc } = _import.Ctx.serializeM;
  var { credits } = _import.Ctx._write;
  var gaya = global.config.style.satu;
  var teks = credits(gaya);
  conn.sendButtonLoc(m.chat, await ( await Ft.fetch(userbot.image.butmag11)).buffer(), teks, footerText, 'Menu', 'Menu', m) 
} else if (selectbutton == 'Uptime') {
  var { send3ButtonLoc } = _import.Ctx.serializeM;
  var gaya = global.config.style.satu; 
  var teks = '*Waktu Berjalan Perangkat*' + '\n\n' + gaya + ' ' + Ft.runtime(Ft.os.uptime())
  conn.send3ButtonLoc(m.chat, await ( await Ft.fetch(userbot.image.butmag12)).buffer(), teks, footerText, 'Speed', 'Speed', 'Owner', 'Owner', 'Runtime', 'Runtime', m)
} else if (selectbutton == 'Speed') {
  var { send3ButtonLoc } = _import.Ctx.serializeM;
  var botName = '*' + userbot.setting.packname + '*';
  var gaya = global.config.style.satu; 
  var teks = '*Kecepatan*' + ' ' + botName + '\n\n' + gaya + ' ' + latensi.toFixed(4) + ' ' + 'ms'
  conn.send3ButtonLoc(m.chat, await ( await Ft.fetch(userbot.image.butmag1)).buffer(), teks, footerText, 'Owner', 'Owner', 'Runtime', 'Runtime', 'Uptime', 'Uptime', m)
} else if (selectbutton == 'Dashboard') {
 let asu = `total commands ${Object.keys(Events).length}\n\n`
 for (i in db.data) {
 asu += `-${i}: ${db.data[i]}\n`
}
 m.reply(asu.trim())
} else if (selectbutton == 'Owner') {
  var { send3ButtonLoc } = _import.Ctx.serializeM;
  var nomor = userbot.owner;
  var teks = 'Ini nomer pembuat bot gak usah chat aneh aneh';
  var conarray = []
  var ownerContact = nomor;
 for (let i of ownerContact.map(v => v + '@s.whatsapp.net')) {
var vname = conn.contacts[i] != undefined ? conn.contacts[i].vname || conn.contacts[i].notify : undefined
  conarray.push({
  "displayName": 'Arifi Razzaq',
  "vcard": `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:${vname ? `${vname}` : `${conn.user.name}`}\nitem1.TEL;waid=${i.split('@')[0]}:${i.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
  }
  )}
  conn.sendMessage(m.chat, {
  "displayName": `${conarray.length} kontak`,
  "contacts": conarray 
 }, 
  "contactsArrayMessage", { 
 quoted: msg 
  })
  conn.send3ButtonLoc(m.chat, await ( await Ft.fetch(userbot.image.butmag10)).buffer(), teks, footerText, 'Runtime', 'Runtime', 'Uptime', 'Uptime', 'Speed', 'Speed', m)
} else if (selectbutton == 'Runtime') {
  var { send3ButtonLoc } = _import.Ctx.serializeM;
  var gaya = global.config.style.satu; 
  var run = process.uptime()
  var teks = '*Waktu Berjalan Bot*' + '\n\n' + gaya + ' ' + Ft.runtime(run)
  conn.send3ButtonLoc(m.chat, await ( await Ft.fetch(userbot.image.butmag9)).buffer(), teks, footerText, 'Uptime', 'Uptime', 'Speed', 'Speed', 'Owner', 'Owner', m)
} else if (selectbutton == 'Status') {
  var { wa_version, mcc, mnc, os_version, device_manufacturer, device_model } = conn.user.phone;
  var { sendButtonLoc } = _import.Ctx.serializeM;
  var { status } = _import.Ctx._write;
  var { count } = _import.Ctx._moment
  var gaya = global.config.style.satu;
  var groups = conn.chats.array.filter(v => v.jid.endsWith('g.us'));
  var privat = conn.chats.array.filter(v => v.jid.endsWith('s.whatsapp.net'));
  var totalChat = await conn.chats.all();
  var ramTwo = `${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB`
  var teks = "「 *𝗦𝗧𝗔𝗧𝗨𝗦 𝗕𝗢𝗧* 」\n\n"
  teks += `${gaya} Group Chats : ${groups.length}\n`
  teks += `${gaya} Private Chats : ${privat.length}\n`
  teks += `${gaya} Total Chats : ${totalChat.length}\n`
  teks += `${gaya} Speed : ${latensi.toFixed(4)} ms\n`
  teks += `${gaya} Public : ${isPublic ? 'true' : 'false'}\n`
  teks += `${gaya} Multi Prefix : ${multi ? 'true' : 'false'}\n\n\n`
  teks += "「 *𝗦𝗧𝗔𝗧𝗨𝗦 𝗗𝗘𝗩𝗜𝗖𝗘* 」\n\n"
  teks += `${gaya} Total Ram : ${ramTwo}\n`
  teks += `${gaya} Platform : ${Ft.os.platform()}\n`
  teks += `${gaya} Hostname : ${Ft.os.hostname()}\n`
  teks += `${gaya} Merk Device : ${device_manufacturer}\n`
  teks += `${gaya} Version WhatsApp : ${wa_version}\n`
  teks += `${gaya} Version OS : ${os_version}\n`
  teks += `${gaya} Version Device : ${device_model}\n`
  teks += `${gaya} MCC : ${mcc}\n`
  teks += `${gaya} MNC : ${mnc}\n`  
  conn.sendButtonLoc(m.chat, await ( await Ft.fetch(userbot.image.butmag8)).buffer(), teks, footerText, 'Menu', 'Menu', m) 
} else if (selectbutton == 'TRUTH') {
  var { send2ButtonLoc } = _import.Ctx.serializeM;
  var trut = ['Pernah suka sama siapa aja? berapa lama?','Kalau boleh atau kalau mau, di gc/luar gc siapa yang akan kamu jadikan sahabat?(boleh beda/sma jenis)','apa ketakutan terbesar kamu?','pernah suka sama orang dan merasa orang itu suka sama kamu juga?','Siapa nama mantan pacar teman mu yang pernah kamu sukai diam diam?','pernah gak nyuri uang nyokap atau bokap? Alesanya?','hal yang bikin seneng pas lu lagi sedih apa','pernah cinta bertepuk sebelah tangan? kalo pernah sama siapa? rasanya gimana brou?','pernah jadi selingkuhan orang?','hal yang paling ditakutin','siapa orang yang paling berpengaruh kepada kehidupanmu','hal membanggakan apa yang kamu dapatkan di tahun ini','siapa orang yang bisa membuatmu sange','siapa orang yang pernah buorangu sange','(bgi yg muslim) pernah ga solat seharian?','Siapa yang paling mendekati tipe pasangan idealmu di sini','suka mabar(main bareng)sama siapa?','pernah nolak orang? alasannya kenapa?','Sebutkan kejadian yang bikin kamu sakit hati yang masih di inget','pencapaian yang udah didapet apa aja ditahun ini?','kebiasaan terburuk lo pas di sekolah apa?']
  var ttrth = trut[Math.floor(Math.random() * trut.length)]
  var teks = '*TRUTH*\n\n' + ttrth;
  conn.send2ButtonLoc(m.chat, await ( await Ft.fetch(userbot.image.butmag6)).buffer(), teks, footerText, 'NEXT', 'TRUTH', 'DARE', 'DARE', m)  
} else if (selectbutton == 'DARE') {
  var { send2ButtonLoc } = _import.Ctx.serializeM;
  var dare = ["Kirim pesan ke mantan kamu dan bilang", "aku masih suka sama kamu","telfon crush/pacar sekarang dan ss ke pemain","pap ke salah satu anggota grup","Bilang 'KAMU CANTIK BANGET NGGAK BOHONG' ke cowo","ss recent call whatsapp","drop emot '🦄💨' setiap ngetik di gc/pc selama 1 hari","kirim voice note bilang can i call u baby?","drop kutipan lagu/quote, terus tag member yang cocok buat kutipan itu","pake foto sule sampe 3 hari","ketik pake bahasa daerah 24 jam","ganti nama menjadi 'gue anak lucinta luna' selama 5 jam","chat ke kontak wa urutan sesuai %batre kamu, terus bilang ke dia 'i lucky to hv you","prank chat mantan dan bilang ' i love u, pgn balikan","record voice baca surah al-kautsar","bilang 'i hv crush on you, mau jadi pacarku gak?' ke lawan jenis yang terakhir bgt kamu chat (serah di wa/tele), tunggu dia bales, kalo udah ss drop ke sini","sebutkan tipe pacar mu!","snap/post foto pacar/crush","teriak gajelas lalu kirim pake vn kesini","pap mukamu lalu kirim ke salah satu temanmu","kirim fotomu dengan caption, aku anak pungut","teriak pake kata kasar sambil vn trus kirim kesini","teriak ' anjimm gabutt anjimmm ' di depan rumah mu","ganti nama jadi ' BOWO ' selama 24 jam","Pura pura kerasukan, contoh : kerasukan maung, kerasukan belalang, kerasukan kulkas, dll"]
  var der = dare[Math.floor(Math.random() * dare.length)]
  var teks = '*DARE*\n\n' + der;
  conn.send2ButtonLoc(m.chat, await ( await Ft.fetch(userbot.image.butmag7)).buffer(), teks, footerText, 'NEXT', 'DARE', 'TRUTH', 'TRUTH', m)  
} else if (selectbutton == 'Donasi') {
  m.reply("https://saweria.co/arifirazzaq2001")
} else if (selectbutton == 'Changelog') {
  var { send3ButtonLoc } = _import.Ctx.serializeM;
  var { date } = _import.Ctx._moment;
  var pkgg = require('../../package.json');
 let name = conn.getName(botNumber) 
 let caption = `Changelog\n`
  caption += `tanggal: ${date}\n`
  caption += `versi saat ini *${pkgg.version}*\n\n`
  caption += `${changelog == '' ? 'Tidak ada changelog yang di tambahkan' : '' || changelog }\n`
  conn.send3ButtonLoc(m.chat, await ( await Ft.fetch(userbot.image.butmag2)).buffer(), caption, footerText, 'Dashboard', 'Dashboard', 'Status', 'Status', 'Donasi', 'Donasi', m)
} else if (command === prefix + "menu") {
  var { menu } = _import.Ctx._write;
  var listMsg = {
title: "「 *𝗦𝗧𝗥𝗘𝗔𝗠 𝗕𝗢𝗧* 」", 
buttonText: 'Daftar Menu',
footerText: footerText,
description: `\nHai kak @${m.sender.split('@')[0]}, Silahkan pilih menu disini`,
sections: [
  {
"title": `Originally Type 1`, 
"rows" : [
  {
"title": "𝗠𝗘𝗡𝗨 𝗟𝗢𝗖𝗔𝗧𝗜𝗢𝗡 𝗕𝗨𝗧𝗧𝗢𝗡",
"rowId": "MenuLOCATION"
  }]
  },{
"title": `Catalog Type 1`, 
"rows" : [
  {
"title": "𝗠𝗘𝗡𝗨 𝗖𝗔𝗧𝗔𝗟𝗢𝗚",
"description": "\nKatalog adalah daftar koleksi sebuah pusat dokumentasi atau beberapa pusat dokumentasi yang disusun menurut sistem tertentu.", 
"rowId": "MenuCATALOG"
  }]
  },{
"title": `Catalog Type 2`, 
"rows" : [
  {
"title": "𝗠𝗘𝗡𝗨 𝗖𝗔𝗧𝗔𝗟𝗢𝗚 𝗣𝗥𝗢𝗗𝗨𝗖𝗧",
"description": "\nKatalog Produk adalah kumpulan produk dan informasi harga mereka. ... Buat daftar diskon untuk menawarkan produk dan layanan dengan harga yang berbeda, tergantung pada jumlah yang dibeli. Mengkonfigurasikan daftar diskon. Mendefinisikan pengukuran atau kuantitas produk Anda akan tersedia.", 
"rowId": "MenuCATALOGv2"
  }]
  },{
"title": `Dokument Type 1`, 
"rows" : [
  {
"title": "𝗠𝗘𝗡𝗨 𝗣𝗣𝗧𝗫",
"description": "\nMicrosoft PowerPoint atau Microsoft Office PowerPoint atau PowerPoint adalah sebuah program komputer untuk presentasi yang dikembangkan oleh Microsoft di dalam paket aplikasi kantoran mereka, Microsoft Office, selain Microsoft Word, Excel, Access dan beberapa program lainnya.", 
"rowId": "MenuPPTX"
  }]
  },{
"title": `Dokument Type 2`,
"rows": [ 
  {
"title": "𝗠𝗘𝗡𝗨 𝗫𝗟𝗦𝗫",
"description": "\nData atau file dengan ekstensi .XLSX adalah sebuah file Microsoft Excel Open XML Spreadsheet yang dibuat memakai aplikasi Microsoft Excel. Namun, karena formatnya open XML, file ini bisa dibuka oleh sejumlah aplikasi, seperti Open Office, Google Docs, hingga Apple Numbers.", 
"rowId": "MenuXLSX"
  }]
  },{
"title": `Dokument Type 3`,
"rows": [ 
  {
"title": "𝗠𝗘𝗡𝗨 𝗗𝗢𝗖𝗫",
"description": "\nDilansir dari Hubspot, Google Docs adalah layanan pengolah kata yang diberikan kepada pengguna Google secara gratis. Singkatnya, jika kamu sudah familiar dengan Microsoft Word, maka Google Docs adalah versi lain yang memungkinkan kamu untuk membuat, mengedit, dan membagikan dokumen tertulis secara online.", 
"rowId": "MenuDOCX"
  }]
  },{
"title": `Dokument Type 4`,
"rows": [ 
  {
"title": "𝗠𝗘𝗡𝗨 𝗭𝗜𝗣",
"description": "\nZIP merupakan format file arsip yang digunakan secara luas untuk mengompresi atau memampatkan satu atau beberapa file bersama-sama menjadi ke dalam satu lokasi sehingga mengurangi ukurannya secara keseluruhan serta memudahkan pemindahan file tersebut. File ZIP bekerja serupa dengan folder standar pada komputer Anda.", 
"rowId": "MenuZIP"
  }]
  },{
"title": `Dokument Type 5`,
"rows": [ 
  {
"title": "𝗠𝗘𝗡𝗨 𝗣𝗗𝗙",
"description": "\nPortable Document Format adalah sebuah format berkas yang dibuat oleh Adobe Systems pada tahun 1993 untuk keperluan pertukaran dokumen digital. Format PDF digunakan untuk merepresentasikan dokumen dua dimensi yang meliputi teks, huruf, citra dan grafik vektor dua dimensi.", 
"rowId": "MenuPDF"
  }]
  }
  ],
  listType: 1
 }
  conn.sendMessage(m.chat, listMsg, MessageType.listMessage, {contextInfo: { mentionedJid: [m.sender]}, quoted:msg })
} else if (command === prefix + "uptime") {
  var { send3ButtonLoc } = _import.Ctx.serializeM;
  var gaya = global.config.style.satu; 
  var teks = '*Waktu Berjalan Perangkat*' + '\n\n' + gaya + ' ' + Ft.runtime(Ft.os.uptime())
  conn.send3ButtonLoc(m.chat, await ( await Ft.fetch(userbot.image.butmag12)).buffer(), teks, footerText, 'Speed', 'Speed', 'Owner', 'Owner', 'Runtime', 'Runtime', m)
} else if (command === prefix + "speed") {
  var { send3ButtonLoc } = _import.Ctx.serializeM;
  var botName = '*' + userbot.setting.packname + '*';
  var gaya = global.config.style.satu; 
  var teks = '*Kecepatan*' + ' ' + botName + '\n\n' + gaya + ' ' + latensi.toFixed(4) + ' ' + 'ms'
  conn.send3ButtonLoc(m.chat, await ( await Ft.fetch(userbot.image.butmag1)).buffer(), teks, footerText, 'Owner', 'Owner', 'Runtime', 'Runtime', 'Uptime', 'Uptime', m)
} else if (command === prefix + "delete") {
  var onlyG = userbot.mess.KhususGrup
  if (!m.isGroup) return m.reply(onlyG)
  conn.deleteMessage(m.chat, { id: msg.message.extendedTextMessage.contextInfo.stanzaId, remoteJid: m.chat, fromMe: true })
} else if (command === prefix + "owner") {
  var { send3ButtonLoc } = _import.Ctx.serializeM;
  var nomor = userbot.owner;
  var teks = 'Ini nomer pembuat bot gak usah chat aneh aneh';
  var conarray = []
  var ownerContact = nomor;
  for (let i of ownerContact.map(v => v + '@s.whatsapp.net')) {
  var vname = conn.contacts[i] != undefined ? conn.contacts[i].vname || conn.contacts[i].notify : undefined
  conarray.push({
  "displayName": 'Arifi Razzaq',
  "vcard": `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:${vname ? `${vname}` : `${conn.user.name}`}\nitem1.TEL;waid=${i.split('@')[0]}:${i.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
  })
  }
  conn.sendMessage(m.chat, {
  "displayName": `${conarray.length} kontak`,
  "contacts": conarray 
  }, 'contactsArrayMessage', { quoted: msg })
  conn.send3ButtonLoc(m.chat, await ( await Ft.fetch(userbot.image.butmag10)).buffer(), teks, footerText, 'Runtime', 'Runtime', 'Speed', 'Speed', 'Uptime', 'Uptime', m)
} else if (command === prefix + "rules") {
  var { sendButtonLoc } = _import.Ctx.serializeM;
  var { rules } = _import.Ctx._write;
  var teks = rules(prefix, l);
  conn.sendButtonLoc(m.chat, await ( await Ft.fetch(userbot.image.butmag3)).buffer(), teks, footerText, 'Menu', 'Menu', m) 
} else if (command === prefix + "credits") {
  var { sendButtonLoc } = _import.Ctx.serializeM;
  var { credits } = _import.Ctx._write;
  var gaya = global.config.style.satu;
  var teks = credits(gaya);
  conn.sendButtonLoc(m.chat, await ( await Ft.fetch(userbot.image.butmag4)).buffer(), teks, footerText, 'Menu', 'Menu', m) 
} else if (command === prefix + "truthdare") {
  var { send2ButtonLoc } = _import.Ctx.serializeM;
  var teks = '*' + userbot.simple.pilihan + '*';
  var trteh = await Ft.getBuffer(userbot.image.getbuff)
  conn.send2ButtonLoc(m.chat, trteh, teks, footerText, 'TRUTH', 'TRUTH', 'DARE', 'DARE', m)
} else if (command === prefix + "changelog") {
  var { send3ButtonLoc } = _import.Ctx.serializeM;
  var { date } = _import.Ctx._moment;
  var pkgg = require('../../package.json');
  let name = conn.getName(botNumber) 
  let caption = `Changelog\n`
  caption += `tanggal: ${date}\n`
  caption += `versi saat ini *${pkgg.version}*\n\n`
  caption += `${changelog == '' ? 'Tidak ada changelog yang di tambahkan' : '' || changelog }\n`
  conn.send3ButtonLoc(m.chat, await ( await Ft.fetch(userbot.image.butmag2)).buffer(), caption, footerText, 'Dashboard', 'Dashboard', 'Status', 'Status', 'Donasi', 'Donasi', m)
} else if (command === prefix + "status") {
  var { wa_version, mcc, mnc, os_version, device_manufacturer, device_model } = conn.user.phone;
  var { sendButtonLoc } = _import.Ctx.serializeM;
  var { status } = _import.Ctx._write;
  var { count } = _import.Ctx._moment
  var gaya = global.config.style.satu;
  var groups = conn.chats.array.filter(v => v.jid.endsWith('g.us'));
  var privat = conn.chats.array.filter(v => v.jid.endsWith('s.whatsapp.net'));
  var totalChat = await conn.chats.all();
  var ramTwo = `${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB`
  var teks = "「 *𝗦𝗧𝗔𝗧𝗨𝗦 𝗕𝗢𝗧* 」\n\n"
  teks += `${gaya} Group Chats : ${groups.length}\n`
  teks += `${gaya} Private Chats : ${privat.length}\n`
  teks += `${gaya} Total Chats : ${totalChat.length}\n`
  teks += `${gaya} Speed : ${latensi.toFixed(4)} ms\n`
  teks += `${gaya} Public : ${isPublic ? 'true' : 'false'}\n`
  teks += `${gaya} Multi Prefix : ${multi ? 'true' : 'false'}\n\n\n`
  teks += "「 *𝗦𝗧𝗔𝗧𝗨𝗦 𝗗𝗘𝗩𝗜𝗖𝗘* 」\n\n"
  teks += `${gaya} Total Ram : ${ramTwo}\n`
  teks += `${gaya} Platform : ${Ft.os.platform()}\n`
  teks += `${gaya} Hostname : ${Ft.os.hostname()}\n`
  teks += `${gaya} Merk Device : ${device_manufacturer}\n`
  teks += `${gaya} Version WhatsApp : ${wa_version}\n`
  teks += `${gaya} Version OS : ${os_version}\n`
  teks += `${gaya} Version Device : ${device_model}\n`
  teks += `${gaya} MCC : ${mcc}\n`
  teks += `${gaya} MNC : ${mnc}\n`  
  conn.sendButtonLoc(m.chat, await ( await Ft.fetch(userbot.image.butmag8)).buffer(), teks, footerText, 'Menu', 'Menu', m) 
} else if (command === prefix + "sider") {
  if (!m.quoted) return m.reply(`Balas pesan bot!`);
  const members = 
  m.quoted.chat.endsWith("g.us") 
  ? (await conn.groupMetadata(m.quoted.chat))
.participants.length - 1 
  : m.quoted.chat.endsWith("@broadcast") 
  ? -1 
  : 1;
  const { reads, 
  deliveries 
  } = await conn.messageInfo(
  m.quoted.chat, 
  m.quoted.id);
const txt = `*Dibaca oleh:*
${reads
  .sort((a, b) => b.t - a.t)
  .map(({ jid, t }) => `@${jid.split`@`[0]}\n_${Ft.formatDate(t * 1000)}_`)
  .join("\n")}
${members > 1 ? `${members - reads.length} tersisa` : ""}

*Terkirim ke:*
${deliveries
  .sort((a, b) => b.t - a.t)
  .map(({ jid, t }) => `@${jid.split`@`[0]}\n_${Ft.formatDate(t * 1000)}_`)
  .join("\n")}
${members > 1 ? `${members - reads.length - deliveries.length} tersisa` : ""}
`.trim();
  m.reply(txt, null, {
  contextInfo: {
  mentionedJid: conn.parseMention(txt),
  },
  });
} else if (command === prefix + "listonline") {
 var onlyG = userbot.mess.KhususGrup
if (!m.isGroup) return m.reply(onlyG)
 const ido = args && /\d+\-\d+@g.us/.test(args[0]) ? args[0] : m.chat
 const online = [...Object.keys(conn.chats.get(ido).presences), botNumber]
  conn.sendMessage(m.chat, 'List Online:\n' + online.map(v => '- @' + v.replace(/@.+/, '')).join `\n`, MessageType.text, {
  quoted: msg,
  contextInfo: {
  mentionedJid: online
  }
  })
} else if (command === prefix + "donasi") {
  m.reply("https://saweria.co/arifirazzaq2001")
} else if (command === prefix + "q") {
  if (!m.quoted) return m.reply("reply message!");
  const qse = conn.serializeM(await m.getQuotedObj());
if (!qse.quoted)
  return m.reply("the message you replied does not contain a reply!");
 await qse.quoted.copyNForward(m.chat, true);
} else if (command === prefix + 'linkgc') {
if (!isBotGroupAdmins) return m.reply(userbot.mess.BotAdmin)
 var linkgc = await conn.groupInviteCode(m.chat)
 m.reply('https://chat.whatsapp.com/' + linkgc)
} else if (command === prefix + "dashboard") {
 const asu = `total commands ${Object.keys(Events).length}\n\n`
 for (i in db.data) {
 asu += `-${i}: ${db.data[i]}\n`
}
 m.reply(asu.trim())
} else if (command === prefix + "sticker") {
const isMedia = type === "imageMessage" || type === "videoMessage";
const isQuotedImage = type === "extendedTextMessage" && content.includes("imageMessage");
const isQuotedVideo = type === "extendedTextMessage" && content.includes("videoMessage");
 m.reply(userbot.mess.wait)
 if (((isMedia && !msg.message.videoMessage) || isQuotedImage) && args.length == 0 ) {
const encmedia = isQuotedImage
  ? JSON.parse(JSON.stringify(msg).replace("quotedM", "m")).message
 .extendedTextMessage.contextInfo
  : msg;
const media = await conn.downloadAndSaveMediaMessage(encmedia);
var ran = "666.webp";
await Ft.ffmpeg(`./${media}`)
  .input(media)
  .on("start", function (cmd) {
    console.log(`Started : ${cmd}`);
  })
  .on("error", function (err) {
    console.log(`Error : ${err}`);
    Ft.fs.unlinkSync(media);
    m.reply(err);
  })
  .on("end", function () {
    console.log("Finish");
    conn.sendMessage(m.chat, Ft.fs.readFileSync(ran), MessageType.sticker, {
  quoted: msg, 
  });
  Ft.fs.unlinkSync(media);
  Ft.fs.unlinkSync(ran);
  })
    .addOutputOptions([
    `-vcodec`,
    `libwebp`,
    `-vf`,
    `scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`,
  ])
  .toFormat("webp")
  .save(ran);
   } else if (
((isMedia && msg.message.videoMessage.seconds < 11) ||
  (isQuotedVideo &&
    msg.message.extendedTextMessage.contextInfo.quotedMessage
 .videoMessage.seconds < 11)) &&
args.length == 0
   ) {
const encmedia = isQuotedVideo
  ? JSON.parse(JSON.stringify(msg).replace("quotedM", "m")).message
 .extendedTextMessage.contextInfo
  : msg;
const media = await conn.downloadAndSaveMediaMessage(encmedia);
var ran = "999.webp";
m.reply(userbot.mess.wait);
await Ft.ffmpeg(`./${media}`)
  .inputFormat(media.split(".")[1])
  .on("start", function (cmd) {
    console.log(`Started : ${cmd}`);
  })
  .on("error", function (err) {
    console.log(`Error : ${err}`);
    Ft.fs.unlinkSync(media);
    var tipe = media.endsWith(".mp4") ? "video" : "gif";
    m.reply(`Gagal, pada saat mengkonversi ${tipe} ke stiker`);
  })
  .on("end", function () {
    console.log("Finish");
    conn.sendMessage(m.chat, Ft.fs.readFileSync(ran), MessageType.sticker, {
  quoted: msg, 
  });
    Ft.fs.unlinkSync(media);
    Ft.fs.unlinkSync(ran);
  })
  .addOutputOptions([
    `-vcodec`,
    `libwebp`,
    `-vf`,
    `scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`,
  ])
  .toFormat("webp")
  .save(ran);
   } else {
m.reply(`Kirim gambar dengan caption ${prefix}sticker\nDurasi Sticker Video 1-9 Detik`);
   } 
} else if (command === prefix + "swm") {
const isImage = (type === 'imageMessage')
const isVideo = (type === 'videoMessage')
const q = body.slice(command.length + 1, body.length)
const isQuotedImage = type === "extendedTextMessage" && content.includes("imageMessage");
const isQuotedVideo = type === "extendedTextMessage" && content.includes("videoMessage");
 if (args.length < 2) return m.reply(`Penggunaan ${command} nama|author`)
 let packname1 = q.split('|')[0] ? q.split('|')[0] : q
 let author1 = q.split('|')[1] ? q.split('|')[1] : ''
 if (isImage || isQuotedImage) {
  let encmedia = isQuotedImage ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
  let media = await conn.downloadAndSaveMediaMessage(encmedia, `./src/cache/sticker/${m.sender}`)
exif.create(packname1, author1, `stickwm_${m.sender}`)
  await Ft.ffmpeg(`${media}`)
.input(media)
.on('start', function (cmd) {
console.log(`Started : ${cmd}`)
})
.on('error', function (err) {
console.log(`Error : ${err}`)
Ft.fs.unlinkSync(media)
m.reply(userbot.mess.api)
})
.on('end', function () {
console.log('Finish')
Ft.exec(`webpmux -set exif ./src/cache/sticker/stickwm_${m.sender}.exif ./src/cache/sticker/${m.sender}.webp -o ./src/cache/sticker/${m.sender}.webp`, async (error) => {
if (error) return m.reply(userbot.mess.api)
conn.sendMessage(m.chat, Ft.fs.readFileSync(`./src/cache/sticker/${m.sender}.webp`), MessageType.sticker, {quoted: msg})
 Ft.fs.unlinkSync(media)
 Ft.fs.unlinkSync(`./src/cache/sticker/${m.sender}.webp`)
 Ft.fs.unlinkSync(`./src/cache/sticker/stickwm_${m.sender}.exif`)
})
})
.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
.toFormat('webp')
.save(`./src/cache/sticker/${m.sender}.webp`)
} else if ((isVideo && msg.message.videoMessage.fileLength < 10000000 || isQuotedVideo && msg.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.fileLength < 10000000)) {
  let encmedia = isQuotedVideo ? JSON.parse(JSON.stringify(msg).replace('quotedM', 'm')).message.extendedTextMessage.contextInfo : msg
  let media = await conn.downloadAndSaveMediaMessage(encmedia, `./src/cache/sticker/${m.sender}`)
  exif.create(packname1, author1, `stickwm_${m.sender}`)
  m.reply(userbot.mess.wait)
 await Ft.ffmpeg(`${media}`)
.inputFormat(media.split('.')[4])
.on('start', function (cmd) {
  console.log(`Started : ${cmd}`)
})
.on('error', function (err) {
  console.log(`Error : ${err}`)
Ft.fs.unlinkSync(media)
    let tipe = media.endsWith('.mp4') ? 'video' : 'gif'
m.reply(userbot.mess.api)
})
.on('end', function () {
  console.log('Finish')
  Ft.exec(`webpmux -set exif ./src/cache/sticker/stickwm_${m.sender}.exif ./src/cache/sticker/${m.sender}.webp -o ./src/cache/sticker/${m.sender}.webp`, async (error) => {
if (error) return m.reply(userbot.mess.api)
conn.sendMessage(m.chat, Ft.fs.readFileSync(`./src/cache/sticker/${m.sender}.webp`), MessageType.sticker, {quoted: msg})
    Ft.fs.unlinkSync(media)
   Ft.fs.unlinkSync(`./src/cache/sticker/${m.sender}.webp`)
    Ft.fs.unlinkSync(`./src/cache/sticker/stickwm_${m.sender}.exif`)
})
})
.addOutputOptions([`-vcodec`,`libwebp`,`-vf`,`scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
.toFormat('webp')
.save(`./src/cache/sticker/${m.sender}.webp`)
} else if (isQuotedSticker) {
  const encmedia = JSON.parse(JSON.stringify(msg).replace('quotedM','m')).message.extendedTextMessage.contextInfo
  const media = await conn.downloadAndSaveMediaMessage(encmedia, `./src/cache/sticker/${m.sender}`)
  exif.create(packname1, author1, `takestick_${m.sender}`)
  Ft.exec(`webpmux -set exif ./src/cache/sticker/takestick_${m.sender}.exif ./src/cache/sticker/${m.sender}.webp -o ./src/cache/sticker/${m.sender}.webp`, async (error) => {
if (error) return m.reply(userbot.mess.api)
  conn.sendMessage(m.chat, Ft.fs.readFileSync(`./src/cache/sticker/${m.sender}.webp`), MessageType.sticker, {quoted: msg})
  Ft.fs.unlinkSync(media)
  Ft.fs.unlinkSync(`./src/cache/sticker/takestick_${m.sender}.exif`)
})
} else {
m.reply(`Kirim gambar/video dengan caption ${prefix}stickerwm nama|author atau tag gambar/video yang sudah dikirim\nNote : Durasi video maximal 10 detik`)
}
} else if (command === prefix + "runtime") {
  var { send3ButtonLoc } = _import.Ctx.serializeM;
  var gaya = global.config.style.satu; 
  var run = process.uptime()
  var teks = '*Waktu Berjalan Bot*' + '\n\n' + gaya + ' ' + Ft.runtime(run)
  conn.send3ButtonLoc(m.chat, await ( await Ft.fetch(userbot.image.butmag9)).buffer(), teks, footerText, 'Uptime', 'Uptime', 'Speed', 'Speed', 'Owner', 'Owner', m)
  };
 if (isCmd && m.isGroup) { 
 console.log(Ft.chalk.bold.rgb(255, 178, 102)
 ('\x1b[1;31m~\x1b[1;37m> [\x1b[1;32mCMD\x1b[1;37m]'), Ft.chalk.bold.rgb(153, 255, 153)
 (command), Ft.chalk.bold.rgb(204, 204, 0)
 ("from"), Ft.chalk.bold.rgb(153, 255, 204)
 (pushName), Ft.chalk.bold.rgb(204, 204, 0)
 ("in"), Ft.chalk.bold.rgb(255, 178, 102)
 (groupMetadata.subject), Ft.chalk.bold('[' + args.length + ']'));
};
 if (isCmd && !m.isGroup) { 
 console.log(Ft.chalk.bold.rgb(255, 178, 102)
 ('\x1b[1;31m~\x1b[1;37m> [\x1b[1;32mCMD\x1b[1;37m]'), Ft.chalk.bold.rgb(153, 255, 153)
 (command), Ft.chalk.bold.rgb(204, 204, 0)
 ("from"), Ft.chalk.bold.rgb(153, 255, 204)
 (pushName), Ft.chalk.bold.rgb(204, 204, 0)
 ("in"), Ft.chalk.bold.rgb(255, 178, 102)
 ("Private Chat"), Ft.chalk.bold('[' + args.length + ']'));
};
 if (m.isGroup && selectbutton) {
 console.log(Ft.chalk.bold.rgb(255, 215, 0)
 ('~' + Ft.chalk.bold.rgb(255, 255, 255)
 ('>')), Ft.chalk.bold.rgb(255, 255, 255)
 ('[' + Ft.chalk.bold.rgb(252, 201, 185)
 ('SBT') + Ft.chalk.bold.rgb(255, 255, 255)
 (']')), Ft.chalk.white('IdButton:'), Ft.chalk.bold.rgb(181, 0, 148)
 (selectbutton), Ft.chalk.white('From:'), Ft.chalk.bold.rgb(153, 102, 204)
 (pushName), Ft.chalk.bold('[' + args.length + ']'));
};
 if (!m.isGroup && selectbutton) {
 console.log(Ft.chalk.bold.rgb(255, 215, 0)
 ('~' + Ft.chalk.bold.rgb(255, 255, 255)
 ('>')), Ft.chalk.bold.rgb(255, 255, 255)
 ('[' + Ft.chalk.bold.rgb(252, 201, 185)
 ('SBT') + Ft.chalk.bold.rgb(255, 255, 255)
 (']')), Ft.chalk.white('IdButton:'), Ft.chalk.bold.rgb(181, 0, 148)
 (selectbutton), Ft.chalk.white('From:'), Ft.chalk.bold.rgb(153, 102, 204)
 (pushName), Ft.chalk.bold.rgb(204, 204, 0)
 ("in"), Ft.chalk.bold.rgb(255, 178, 102)
 ("Private Chat"), Ft.chalk.bold('[' + args.length + ']'));
};
 if (m.isGroup && listButton) { 
 console.log(Ft.chalk.bold.rgb(255, 255, 167)
 ('~' + Ft.chalk.bold.rgb(255, 255, 255)
 ('>')), Ft.chalk.bold.rgb(255, 255, 255)
 ('[' + Ft.chalk.bold.rgb(252, 201, 185)
 ('LMS') + Ft.chalk.bold.rgb(255, 255, 255)
 (']')), Ft.chalk.white('IdList:'), Ft.chalk.bold.rgb(224, 173, 66)
 (listButton), Ft.chalk.white('From:'), Ft.chalk.bold.rgb(0, 170, 255)
 (pushName + groupName), Ft.chalk.bold('[' + args.length + ']'));
};
 if (!m.isGroup && listButton) { 
 console.log(Ft.chalk.bold.rgb(255, 255, 167)
 ('~' + Ft.chalk.bold.rgb(255, 255, 255)
 ('>')), Ft.chalk.bold.rgb(255, 255, 255)
 ('[' + Ft.chalk.bold.rgb(252, 201, 185)
 ('LMS') + Ft.chalk.bold.rgb(255, 255, 255)
 (']')), Ft.chalk.white('IdList:'), Ft.chalk.bold.rgb(224, 173, 66)
 (listButton), Ft.chalk.white('From:'), Ft.chalk.bold.rgb(0, 170, 255)
 (pushName), Ft.chalk.bold.rgb(204, 204, 0)
 ("in"), Ft.chalk.bold.rgb(255, 178, 102)
 ("Private Chat"), Ft.chalk.bold('[' + args.length + ']'));
};
 if (m.isGroup && budy) {
 console.log(Ft.chalk.bold.rgb(135,121,78)
 ("[TXT]"), Ft.chalk.bold.rgb(244,199,170)
 (budy), Ft.chalk.bold.rgb(230,113,181)
 (pushName + groupName), Ft.chalk.bold('[' + args.length + ']'));
};
  } catch (e) {
    e = String(e);
    if (!e.includes("c.isZero")) {
    return
    }
    if (e.includes("startsWith")) {
    return
    }
    if (e.includes("this.isZero")) {
    return
    } 
 const time_error = Ft.moment.tz('Asia/Jakarta').format('HH:mm:ss')
    console.log(Ft.chalk.bold.rgb(255, 182, 193)
  ('~' + Ft.chalk.bold.rgb(255, 255, 255)
  ('>')), Ft.chalk.bold.rgb(255, 255, 255)
  ('[' + Ft.chalk.bold.rgb(119, 221, 119)
  ('ERR') + Ft.chalk.bold.rgb(255, 255, 255)
  (']')), Ft.chalk.bold.rgb(244,199,170)
  (time_error), Ft.chalk.bold.rgb(0, 138, 175)
  (e))
    }
  }
}