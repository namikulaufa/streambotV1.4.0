module.exports = {
Ctx: {
  serializeM: require("../library/Assets/serialize.js"), 
  _SCMD: require("../library/Function/SCMD.js"),
  EXIF: require('../library/Function/exif.js'),
  _moment: require("../library/Assembly/moment.js"),
  funfunc: require('../library/Assembly/func'),
  _UserDB: require("./index.2.js"), 
  _write: require("./index.3.js"), 
  _classFt: require("./index.4.js")
  }
}